package model;

import java.io.Serializable;

public class Student extends Person{
	
	private String maSV;

	public String getMaSV() {
		return maSV;
	}

	public void setMaSV(String maSV) {
		this.maSV = maSV;
	}

	
	
}
